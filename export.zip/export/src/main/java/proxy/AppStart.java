package proxy;

/**
 * @description:AppStart
 * @author:pxf
 * @data:2023/03/02
 **/
/**委托类**/
public interface AppStart {
    public int startApp();
    public int shutDownApp();
}
