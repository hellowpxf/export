package utils;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import java.security.Key;
import java.security.SecureRandom;

/**
 * @description:DesUtil
 * @author:pxf
 * @data:2023/07/28
 **/
public class DesUtil {
    private static Key key;
    /**
     * 设置秘钥key
     */
    private static String KEY_STR="sygjj";
    private static String CHARSETNAME="UTF-8";
    private static String ALGORITHM="DES/ECB/PKCS5Padding";
    static{
        try{
            //生成DES算法对象
            KeyGenerator generator=KeyGenerator.getInstance(ALGORITHM);
            //运用SHA1安全策略
            SecureRandom secureRandom=SecureRandom.getInstance("SHA1PRNG");
            //设置上密钥种子
            secureRandom.setSeed(KEY_STR.getBytes());
            //初始化基于SHA1的算法对象
            generator.init(secureRandom);
            //生成密钥对象
            key=generator.generateKey();
            generator=null;
        }catch(Exception e){
            throw new RuntimeException(e);
        }
    }


    /**
     * 获取加密的信息
     * @param str
     * @return
     */

    public static String getEncryptString(String str){
        //基于BASE64编码，接收byte[]并转换成String
        BASE64Encoder base64Encoder=new BASE64Encoder();
        try {
            // 按UTF8编码
            byte[] bytes = str.getBytes(CHARSETNAME);
            // 获取加密对象
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            // 初始化密码信息
            cipher.init(Cipher.ENCRYPT_MODE, key);
            // 加密
            byte[] doFinal = cipher.doFinal(bytes);
            // byte[]to encode好的String并返回
            return base64Encoder.encode(doFinal);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * 获取解密之后的信息
     *
     * @param str
     * @return
     */
    public static String getDecryptString(String str) {
        // 基于BASE64编码，接收byte[]并转换成String
        BASE64Decoder base64decoder = new BASE64Decoder();
        try {
            // 将字符串decode成byte[]
            byte[] bytes = base64decoder.decodeBuffer(str);
            // 获取解密对象
            Cipher cipher = Cipher.getInstance(ALGORITHM);
            // 初始化解密信息
            cipher.init(Cipher.DECRYPT_MODE, key);
            // 解密
            byte[] doFinal = cipher.doFinal(bytes);
            // 返回解密之后的信息
            return new String(doFinal, CHARSETNAME);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        System.out.println(getDecryptString("CG/QB1TUrk+qENXDvvzZ7O/kH37/xkAIm6NqLfe1MLCH4q6U5OqRXJpiyiBwnHA/Z/RHIX++KO2ctrxFYm9xZR94IohP9FUN+nacCCXnVfGL3eYvI9q4O/xQo8RKGtIRdNDa0q8+ISBSOnRrDaS+oT2N1wrUpiXoSsRm5NWu5sijXGlrGcyI/yFcI46M/a+tlPbNEGW5EPm2H9JZRX6tpgyI8yQHZ9eIS3EmOiWahSfrtCyr810bH9RqLArRePcyJEQySHs6DR3jbc7SOXCuwpEaMwYbjg3vK9/rpOOabBsSGE23pRsjJwa205w1PEhCEUWCoJqakqLbRvgAdgFE7EPsKB2N8jmX9lUG67etH/4Pg0n+9NM88Ou16nPJ29K6Dz7vo1cvQ2Oj7uqEuXC/PA9vuIE1TPl148W5OyaJhxLFsH/++ynjjsJiQp64v05EL04/IyVfMytWapAA2umT6Vyrg814iQq+FVsVpVCUj4TB1/iN79YSR9HoEh5YyyZRNbSW1s/ICLhtvU9O4fqzo5rHiSGXr70/3nLqvMeNb8VudxQcYUKR5fwX4i+fLb0g7jmBQAMC1P6DPozArz2T1lReYRkJlpqD6ABKpWBe0Frzf25lw2POCBVDfqVmMC91H7Wk10q9FGqvq8qQ+Y38VwrWpBht3cFwnz6NtR9C7hzYtNEg/uoX2Wl8JBh4tiZXdttZDaTaElheRNOASQZJHaK/lKCx4CCO/pnNyJSMLuX6P28irgUJvoWDE2R/PxoOabAp0f9Zpa4YIMWqB1wIDnRxNHy+ZuZM04gOpbYuzZ7Aiusz5rGBF6wlHwKfWVVoI8PleagX6eTzvNH0rNgMcrXEoLg/esYhJPdCHAUKzunRaE7mK1QevSKJW5U0saU+1m2W/BGr/dcfQrS0AlPF7gHOLKWFGdIuBkiUxk2OFz/6UfxiIYju9c7UaEw6NpTMsqXkPxEmkpn2yqDafAgAlqXIX7ywjK2fQouF5+5/S227HrwfFMp+sruE5n7b+5ZZ3ujSU1reNMWi8DmiKWCIJh2VHBNMlVCYwv8ubpAsvsps+7iACYpPJLB+GPUllxQq+EBzvUidw9xdQ2RDcOtTFImvhIDR46rgcm7mWyLsOi7a4uBUUoNF4mTUbMwWlGFJQkLz2PoQ3uPkwzSjEsavnLO4brtvfFDfjRij0WferXhj228EU8eHOnkbcmxI/yYN4DC/6Uh+0RXxC3NFmi0LUCtWVj8RTWoO0SNZjNAe06UBbLluFFMdZ4vFGdEIiNCtZ/RHIX++KO2ctrxFYm9xZVBrmLpCDIIc1w4vD7wfJn/FpqAvty4iVU7rVLDXacmdxZ+fDK3ErcQsd70tdFNDPj2N1wrUpiXoSsRm5NWu5sgFeksAdE3MEiM1XQBV41yjIZUc8pSOaWbIOAqoHyU3UAyI8yQHZ9eIS3EmOiWahSdgXf96U50itjJyoYOkJl+rMHNvBCvHRo+hgra2WKIiTZEaMwYbjg3vK9/rpOOabBuQewcsrzUvk3Gh6Ix+Y6N7VKhg8A9mXeft4vStD+4kVFH+PV2cy+0oseGDOb0U+igPg0n+9NM88Ou16nPJ29K6zR5PQQHpmxIRUltX61Yr25nUU4L1VvPe9G55QhJhvqQhVqRKujgTv5zKSAeJjijzwbSvGyWaOb3S4BGQA0bBYUfazG/dxjGLYwylrdyFHBBIKIRQB0kiqb250is77cHMNbSW1s/ICLhtvU9O4fqzo7OIId3Qim7YXCYLMbcZYDkaZ9P2tQkmOZFGRnEXYwZkAo1thaJXfJ2d88hNgURuj6lxihSsV+vOR6vxYDX5TDDzf25lw2POCBVDfqVmMC91H7Wk10q9FGqvq8qQ+Y38VwrWpBht3cFwnz6NtR9C7hyyLTwNupi5Nir+U7Y1ojOIdttZDaTaElheRNOASQZJHc9cejwa5G3X/4gZ33jizM/6P28irgUJvoWDE2R/PxoOabAp0f9Zpa4YIMWqB1wIDnRxNHy+ZuZM04gOpbYuzZ7Aiusz5rGBF6wlHwKfWVVoI8PleagX6eTzvNH0rNgMchmHC5sZkXVplItGJyk3t5qfktTPZZtoIJMLxvoTssil1m2W/BGr/dcfQrS0AlPF7gHOLKWFGdIuBkiUxk2OFz/6UfxiIYju9c7UaEw6NpTMsqXkPxEmkpn2yqDafAgAlqXIX7ywjK2fQouF5+5/S22oKDx913E5/Pxo/TOEP7WqmqTtQx+cTjQ8fBwwwLMV8x2VHBNMlVCYwv8ubpAsvsps+7iACYpPJLB+GPUllxQq+EBzvUidw9xdQ2RDcOtTFImvhIDR46rgcm7mWyLsOi7a4uBUUoNF4mTUbMwWlGFJvFs7n6dfwYVonhfu/T/gACrOLiRYZIG+gif6HyMKpxlj228EU8eHOnkbcmxI/yYN4DC/6Uh+0RXxC3NFmi0LUCtWVj8RTWoO0SNZjNAe06UBbLluFFMdZ4vFGdEIiNCtZ/RHIX++KO2ctrxFYm9xZZwQ6DjMw80JIqVGpw+uM8q4dhhM5M2nYpEPFFTqDs3VxZ+fDK3ErcQsd70tdFNDPj2N1wrUpiXoSsRm5NWu5sgFeksAdE3MEiM1XQBV41yjIZUc8pSOaWbIOAqoHyU3UAyI8yQHZ9eIS3EmOiWahSc9vhcU+i5A+C9ezaYDEQQP+4wjD6Bvkd3smJZmY/IEnpEaMwYbjg3vK9/rpOOabBuQewcsrzUvk3Gh6Ix+Y6N7VKhg8A9mXeft4vStD+4kVFH+PV2cy+0oseGDOb0U+igPg0n+9NM88Ou16nPJ29K67EdJX+cWlk6NN7d8gYRYGnoQzcCfKAUWbtfxHjCb4855p9UaW5LhLnRwHvxMjqlowbSvGyWaOb3S4BGQA0bBYUfazG/dxjGLYwylrdyFHBBIKIRQB0kiqb250is77cHMNbSW1s/ICLhtvU9O4fqzoxv/xqG4IwpgyUGJM0+uJKwaZ9P2tQkmOZFGRnEXYwZkxDuax7nfSz9FXHZ8maOV4alxihSsV+vOR6vxYDX5TDDzf25lw2POCBVDfqVmMC91H7Wk10q9FGqvq8qQ+Y38VwrWpBht3cFwnz6NtR9C7hztL5hul7RhK2Wwrsfk2PpQdttZDaTaElheRNOASQZJHS3GfJvlHZ2AJnd4Vu76RMX6P28irgUJvoWDE2R/PxoOabAp0f9Zpa4YIMWqB1wIDnRxNHy+ZuZM04gOpbYuzZ7Aiusz5rGBF6wlHwKfWVVoI8PleagX6eTzvNH0rNgMcj21Ui0ZRmHfDdVphC0mhqVGAw5Jnb0BmU3HF2yxuvtz1m2W/BGr/dcfQrS0AlPF7gHOLKWFGdIuBkiUxk2OFz/6UfxiIYju9c7UaEw6NpTMsqXkPxEmkpn2yqDafAgAlqXIX7ywjK2fQouF5+5/S20y192Z3Nihzl0SA3tXUPxaSANIOVSvUj5dN0pwdyX6hx2VHBNMlVCYwv8ubpAsvsps+7iACYpPJLB+GPUllxQq+EBzvUidw9xdQ2RDcOtTFImvhIDR46rgcm7mWyLsOi7a4uBUUoNF4mTUbMwWlGFJWM7Hp2xroCncIJMzn8GKjANtXZlNVNLZ64YY88cR3BRj228EU8eHOnkbcmxI/yYN4DC/6Uh+0RXxC3NFmi0LUCtWVj8RTWoO0SNZjNAe06UBbLluFFMdZ4vFGdEIiNCtZ/RHIX++KO2ctrxFYm9xZVyC4x1hz+swmuwDY/YjXR0i73Y694FEOJ3wiO8+CkQjxZ+fDK3ErcQsd70tdFNDPj2N1wrUpiXoSsRm5NWu5sgFeksAdE3MEiM1XQBV41yjIZUc8pSOaWbIOAqoHyU3UAyI8yQHZ9eIS3EmOiWahSdyLfjo/yhDDhxg7YS5PKRNIWcEAtT0gcz/ZKgY2+kLoZEaMwYbjg3vK9/rpOOabBuQewcsrzUvk3Gh6Ix+Y6N7VKhg8A9mXeft4vStD+4kVFH+PV2cy+0oseGDOb0U+igPg0n+9NM88Ou16nPJ29K6BEG8GMxFsb/K8L0czfync4a1mcltNKIr8i8C8jVXNEnutW2dP9sktv/7q9pSjwVIwbSvGyWaOb3S4BGQA0bBYQNc15xYlmSM/c1ZxZjmQ9qw41rEVc9/I9q2TzJAXdUdGSS2Yg+ssxC67HCcvKBku6cxj9RnOd8Eish+kLktQVISh3pGUbPRzw+ABXqm/32Ixwcni7eGRwWJyy27/DoZSfkKX30+muCFrk+Z5N9N2Rk="));
    }
}
