package document;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.stereotype.Service;
import utils.ConstantUtils;
import utils.HttpUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;


/**
 * @description:GenerateSubjectService
 * @author:pxf
 * @data:2023/03/20
 **/
@Service
public class GenerateSubjectService {
   private static HashMap hashMap =null;
    public boolean generateCore(String body, HttpServletResponse response, HttpServletRequest request) throws IOException {
        //转发接口获取数据
        String url  = "https://appcs.jbysoft.com/SXDY/business/common/matterDefinitionCombine$m=query.service";
        //获取header
        HashMap map = HttpUtils.setPostHeader(request);
        String str =  HttpUtils.doPost(url,map,body);
        System.out.println(str);
        //创建一个工作簿
        HSSFWorkbook sheets = new HSSFWorkbook();
        HSSFSheet sheet = sheets.createSheet();
        //设置表头
        setTableHeader(sheet);
        //包装数据
        getManageObjectProperties(sheet,str,map);

        //调整格式
        adjustmentCell(sheet,sheets);
        //声明输出流
        OutputStream os = null;
        //设置响应头
        setResponseHeader(response,"subject.xlsx");
        try {
            os = response.getOutputStream();
            sheets.write(os);
            sheets.close();
        } catch (Exception e) {
            e.printStackTrace();
            os.close();
            return  false;
        }
        return  true;
    }

    /**
     * 获取对象定义属性
     */
    public static void getManageObjectProperties(HSSFSheet sheet,String str,HashMap map) throws IOException {
        JSONObject responseObject = JSONObject.parseObject(str);
        //填充表数据
        System.out.println(responseObject);
        if(responseObject.getBoolean("success")) {
            JSONArray outArray = responseObject.getJSONArray("results");
            JSONArray attributes = outArray.getJSONObject(0).getJSONArray(ConstantUtils.Attribute);
            int rowNum = 1;
            for (int i = 0; i <attributes.size() ; i++) {
                JSONObject attributej = attributes.getJSONObject(i);
                JSONArray attribute = attributej.getJSONArray(ConstantUtils.Attribute);
                for (int j = 0; j <attribute.size() ; j++) {
                    JSONObject bj = attribute.getJSONObject(j);
                    JSONObject at = attribute.getJSONObject(j).getJSONObject(ConstantUtils.AttributeType);
                    HSSFRow row = sheet.createRow(rowNum);
                    //属性名称
                    HSSFCell cell3 = row.createCell(3);
                    cell3.setCellValue(bj.getString(ConstantUtils.FieldName));
                    //属性别名
                    HSSFCell cell4 = row.createCell(4);
                    cell4.setCellValue(bj.getString(ConstantUtils.Alias));
                    //分步名称
                    HSSFCell cell5 = row.createCell(5);
                    cell5.setCellValue(ConstantUtils.DoubleLine);
                    //是否支持模糊搜索
                    HSSFCell cell6 = row.createCell(6);
                    cell6.setCellValue(isSupportFuzzySearch(bj.getInteger(ConstantUtils.IsFuzzySearch)
                            ,bj.getInteger(ConstantUtils.caseSensitive)));
                    //是否显示
                    HSSFCell cell7 = row.createCell(7);
                    cell7.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfXS)));
                    //是否编辑
                    HSSFCell cell8 = row.createCell(8);
                    cell8.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfBJ)));
                    //是否编辑
                    HSSFCell cell9 = row.createCell(9);
                    cell9.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfBt)));
                    //是否修改算法
                    HSSFCell cell10 = row.createCell(10);
                    cell10.setCellValue(fillAlgorith(10,bj,attribute,at.getInteger(ConstantUtils.SfXGSF)));
                    //默认值
                    HSSFCell cell11 = row.createCell(11);
                    cell11.setCellValue(ConstantUtils.DoubleLine);
                    //提示语
                    HSSFCell cell12 = row.createCell(12);
                    cell12.setCellValue(ConstantUtils.DoubleLine);
                    //是否作为流程参数（分支或消息提醒
                    HSSFCell cell13 = row.createCell(13);
                    cell13.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SFZwLXfZTJ)));
                    //是否作为审批规则参数
                    HSSFCell cell14 = row.createCell(14);
                    cell14.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SFZwLXfZTJ)));
                    //是否作为审批规则参数
                    HSSFCell cell15 = row.createCell(15);
                    cell15.setCellValue(ConstantUtils.SfBT0);
                    //流程节点设置属性
                    HSSFCell cell16 = row.createCell(16);
                    cell16.setCellValue(setNodeMessage(at.getInteger(ConstantUtils.sfxzlcjd),
                            at.getInteger(ConstantUtils.sfzyfymxs),at.getJSONArray(ConstantUtils.LCJDSXDATE)));
                    //是否在变更清册中展示
                    HSSFCell cell17 = row.createCell(17);
                    cell17.setCellValue(ConstantUtils.DoubleLine);
                    //登录信息
                    HSSFCell cell18 = row.createCell(18);
                    cell18.setCellValue(Assert__(bj.getInteger(ConstantUtils.LoginInfo),map));
                    //联想搜索显示属性
                    HSSFCell cell19 = row.createCell(19);
                    cell19.setCellValue(Assert__(bj.getString(ConstantUtils.AssociationDisplayContent)));
                    //联想查询类型
                    HSSFCell cell20 = row.createCell(20);
                    cell20.setCellValue(ConstantUtils.DoubleLine);
                    //画像跳转
                    HSSFCell cell21 = row.createCell(21);
                    cell21.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SFTZHX)));
                    //办理规则
                    HSSFCell cell22 = row.createCell(22);
                    cell22.setCellValue(ConstantUtils.SfBT0);
                    //是否作为公共属性
                    HSSFCell cell23 = row.createCell(23);
                    cell23.setCellValue(ConstantUtils.SfBT0);
                    //属性渲染列宽
                    HSSFCell cell24 = row.createCell(24);
                    cell24.setCellValue(ConstantUtils.DoubleLine);
                    //算法
                    HSSFCell cell25 = row.createCell(25);
                    cell25.setCellValue(fillAlgorith(25,bj,attribute,at.getInteger(ConstantUtils.SfXGSF)));
                    //是否修改为互联互通
                    HSSFCell cell26 = row.createCell(26);
                    cell26.setCellValue(ConstantUtils.DoubleLine);
                    //是否配置调用条件
                    HSSFCell cell27 = row.createCell(27);
                    cell27.setCellValue(ConstantUtils.DoubleLine);
                    //是否显示放大镜图标
                    HSSFCell cell28 = row.createCell(28);
                    cell28.setCellValue(assertISMustWriter(bj.getInteger(ConstantUtils.SFXSFDJTB)));
                    //是否配置时间范围
                    HSSFCell cell29 = row.createCell(29);
                    cell29.setCellValue(ConstantUtils.DoubleLine);
                    //数据范围
                    HSSFCell cell30 = row.createCell(30);
                    cell30.setCellValue(ConstantUtils.DoubleLine);
                    //属性样式算法
                    HSSFCell cell31 = row.createCell(31);
                    cell31.setCellValue(ConstantUtils.DoubleLine);
                    //属性占位列数
                    HSSFCell cell32 = row.createCell(32);
                    cell32.setCellValue(ConstantUtils.DoubleLine);
                    //下拉框展示条数
                    HSSFCell cell33 = row.createCell(33);
                    cell33.setCellValue(Assert__(at.getString(ConstantUtils.XLKZSTS)));
                    //管理属性隐藏时是否清空属性数据
                    HSSFCell cell34 = row.createCell(34);
                    cell34.setCellValue(Assert__(at.getInteger(ConstantUtils.SFQKSJ)));
                    //属性规则强控时是否需退出页面
                    HSSFCell cell35 = row.createCell(35);
                    cell35.setCellValue(Assert__(at.getInteger(ConstantUtils.SFTCYM)));
                    //是否配置刷新实例数据
                    HSSFCell cell36 = row.createCell(36);
                    cell36.setCellValue(Assert__(at.getInteger(ConstantUtils.SFPZSXSLSJ)));
                    //下拉框展示方式
                    HSSFCell cell37 = row.createCell(37);
                    cell37.setCellValue(AssertXLKZSFS__(at.getInteger(ConstantUtils.xlkzsfs)));
                    //事项拥有属性和其他对象属性赋值关系
                    HSSFCell cell38 = row.createCell(38);
                    cell38.setCellValue(ConstantUtils.DoubleLine);
                    //集成读卡设备
                    HSSFCell cell39 = row.createCell(39);
                    cell39.setCellValue(ConstantUtils.DoubleLine);
                    //读卡属性和事项拥有属性赋值关系
                    HSSFCell cell40 = row.createCell(40);
                    cell40.setCellValue(ConstantUtils.DoubleLine);
                    //是否加密
                    HSSFCell cell41 = row.createCell(41);
                    cell41.setCellValue(ConstantUtils.DoubleLine);
                    //是否加签
                    HSSFCell cell42 = row.createCell(42);
                    cell42.setCellValue(ConstantUtils.DoubleLine);
                    //是否加密展示
                    HSSFCell cell43 = row.createCell(43);
                    cell43.setCellValue(Assert__(at.getInteger(ConstantUtils.sfjmzs)));
                    //办理规则
                    HSSFCell cell44 = row.createCell(44);
                    cell44.setCellValue(ConstantUtils.DoubleLine);
                    rowNum++;
                }
            }
        }
    }



    /* *//**对象名称	属性别名	属性值		被影响的属性名称		是否显示	是否可编辑	是否必填	"是否作为流程参数（分支或消息提醒）
     "	是否作为审批规则参数	流程节点属性设置	属性占位列数

     * 获取对象定义属性
     *//*
    public static void getManageObjectProperties2(HSSFSheet sheet,String str) throws IOException {
        JSONObject responseObject = JSONObject.parseObject(str);
        //填充表数据
        if(responseObject.getBoolean("success")) {
            JSONArray outArray = responseObject.getJSONArray("results");
            JSONArray attributes = outArray.getJSONObject(0).getJSONArray(ConstantUtils.Attribute);
            int rowNum = 1;
            for (int i = 0; i <attributes.size() ; i++) {
                JSONObject attributej = attributes.getJSONObject(i);
                JSONArray attributeP = attributej.getJSONArray(ConstantUtils.Attribute);
                for (int j = 0; j <attributeP.size() ; j++) {
                    JSONArray objects = attributeP.getJSONArray(j);
                    if(objects ==null){
                        return;
                    }
                    for (int k = 0; k <objects.size() ; k++) {
                        JSONObject bj = attributeP.getJSONObject(k);
                        JSONObject at = attributeP.getJSONObject(k).getJSONObject(ConstantUtils.AttributeType);
                        HSSFRow row = sheet.createRow(rowNum);

                        //属性名称
                        HSSFCell cell1 = row.createCell(1);
                        cell1.setCellValue(bj.getString(ConstantUtils.YXSX));

                        //对象名称
                        HSSFCell cell2 = row.createCell(2);
                        cell2.setCellValue(bj.getString(ConstantUtils.YXSX));
                        //属性名称
                        HSSFCell cell3 = row.createCell(3);
                        cell3.setCellValue(bj.getString(ConstantUtils.FieldName));

                        //属性值
                        String string = at.getJSONArray("sxdymrz").getJSONObject(0).getString("name");
                        HSSFCell cell4 = row.createCell(4);
                        cell4.setCellValue(bj.getString(ConstantUtils.Alias));
                        //分步名称
                        HSSFCell cell5 = row.createCell(5);
                        cell5.setCellValue(ConstantUtils.DoubleLine);
                        //是否支持模糊搜索
                        HSSFCell cell6 = row.createCell(6);
                        cell6.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.IsFuzzySearch)));
                        //是否显示
                        HSSFCell cell7 = row.createCell(7);
                        cell7.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfXS)));
                        //是否编辑
                        HSSFCell cell8 = row.createCell(8);
                        cell8.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfBJ)));
                        //是否编辑
                        HSSFCell cell9 = row.createCell(9);
                        cell9.setCellValue(assertISMustWriter(at.getInteger(ConstantUtils.SfBt)));
                        rowNum++;
                    }
                }
            }
        }
    }*/
    /**
     * 判断是否必填是否显示
     */
    public static  String assertISMustWriter(Integer s) {
        if (s ==null){
            return "否";
        }
        if(s==0){
            return ConstantUtils.SfBT0;
        }else if(s==1){
            return ConstantUtils.SfBT1;
        }else if(s==2){
            return ConstantUtils.SfBT2;
        }else {
            return "";
        }
    }

    /**
     * 判断是否必填是否显示
     */
    public static  String assertISMustWriter(JSONArray jsonArray) {
        if (jsonArray ==null){
            return "否";
        }
        if(jsonArray.size()<=0){
            return ConstantUtils.SfBT0;
        }else{
            return ConstantUtils.SfBT1;
        }
    }
    /** 设置浏览器下载响应头
     */
    private static void setResponseHeader(HttpServletResponse response, String fileName) {
        try {
            try {
                fileName = new String(fileName.getBytes(),"ISO8859-1");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            response.setContentType("application/octet-stream;charset=UTF-8");
            response.setHeader("Content-Disposition", "attachment;filename="+ fileName);
            response.addHeader("Pargam", "no-cache");
            response.addHeader("Cache-Control", "no-cache");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    /**
     * 设置表头
     */
    private static void setTableHeader(HSSFSheet sheet){
        HSSFRow row = sheet.createRow(0);
        //属性名称
        HSSFCell cell3 = row.createCell(3);
        cell3.setCellValue("属性名称");
        //属性别名
        HSSFCell cell4 = row.createCell(4);
        cell4.setCellValue("属性别名");
        //分步名称
        HSSFCell cell5 = row.createCell(5);
        cell5.setCellValue("分步名称");
        //是否支持模糊搜索
        HSSFCell cell6 = row.createCell(6);
        cell6.setCellValue("是否支持模糊搜索");
        //是否显示
        HSSFCell cell7 = row.createCell(7);
        cell7.setCellValue("是否显示");
        //是否编辑
        HSSFCell cell8 = row.createCell(8);
        cell8.setCellValue("是否编辑");
        //是否必填
        HSSFCell cell9 = row.createCell(9);
        cell9.setCellValue("是否必填");
        //是否修改算法
        HSSFCell cell10 = row.createCell(10);
        cell10.setCellValue("是否修改算法");
        //默认值
        HSSFCell cell11 = row.createCell(11);
        cell11.setCellValue("默认值");
        //提示语
        HSSFCell cell12 = row.createCell(12);
        cell12.setCellValue("提示语");
        //是否作为流程参数（分支或消息提醒
        HSSFCell cell13 = row.createCell(13);
        cell13.setCellValue("是否作为流程参数（分支或消息提醒");
        //是否作为审批规则参数
        HSSFCell cell14 = row.createCell(14);
        cell14.setCellValue("是否作为审批规则参数");
        //是否子流程参数
        HSSFCell cell15 = row.createCell(15);
        cell15.setCellValue("是否子流程参数");
        //流程节点设置属性
        HSSFCell cell16 = row.createCell(16);
        cell16.setCellValue("流程节点设置属性");
        //是否在变更清册中展示
        HSSFCell cell17 = row.createCell(17);
        cell17.setCellValue("是否在变更清册中展示");
        //登录信息
        HSSFCell cell18 = row.createCell(18);
        cell18.setCellValue("登录信息");
        //联想搜索显示属性
        HSSFCell cell19 = row.createCell(19);
        cell19.setCellValue("联想搜索显示属性");
        //联想查询类型
        HSSFCell cell20 = row.createCell(20);
        cell20.setCellValue("联想查询类型");
        //画像跳转
        HSSFCell cell21 = row.createCell(21);
        cell21.setCellValue("画像跳转");
        //办理规则
        HSSFCell cell22 = row.createCell(22);
        cell22.setCellValue("办理规则");
        //是否作为公共属性
        HSSFCell cell23 = row.createCell(23);
        cell23.setCellValue("是否作为公共属性");
        //属性渲染列宽
        HSSFCell cell24 = row.createCell(24);
        cell24.setCellValue("属性渲染列宽");
        //算法
        HSSFCell cell25 = row.createCell(25);
        cell25.setCellValue("算法");
        //是否修改为互联互通
        HSSFCell cell26 = row.createCell(26);
        cell26.setCellValue("是否修改为互联互通");
        //是否配置调用条件
        HSSFCell cell27 = row.createCell(27);
        cell27.setCellValue("是否配置调用条件");
        //是否显示放大镜图标
        HSSFCell cell28 = row.createCell(28);
        cell28.setCellValue("是否显示放大镜图标");
        //是否配置时间范围
        HSSFCell cell29 = row.createCell(29);
        cell29.setCellValue("是否配置时间范围");
        //数据范围
        HSSFCell cell30 = row.createCell(30);
        cell30.setCellValue("数据范围");
        //属性样式算法
        HSSFCell cell31 = row.createCell(31);
        cell31.setCellValue("属性样式算法");
        //属性占位列数
        HSSFCell cell32 = row.createCell(32);
        cell32.setCellValue("属性占位列数");

        //下拉框展示方式
        HSSFCell cell33 = row.createCell(33);
        cell33.setCellValue("下拉框展示条数");
        //事项拥有属性和其他对象属性赋值关系
        HSSFCell cell34 = row.createCell(34);
        cell34.setCellValue("管理属性隐藏时是否清空属性数据");
        //集成读卡设备
        HSSFCell cell35 = row.createCell(35);
        cell35.setCellValue("属性规则强控时是否需退出页面");
        //读卡属性和事项拥有属性赋值关系
        HSSFCell cell36 = row.createCell(36);
        cell36.setCellValue("是否配置刷新实例数据");

        //下拉框展示方式
        HSSFCell cell37 = row.createCell(37);
        cell37.setCellValue("下拉框展示方式");
        //事项拥有属性和其他对象属性赋值关系
        HSSFCell cell38 = row.createCell(38);
        cell38.setCellValue("事项拥有属性和其他对象属性赋值关系");
        //集成读卡设备
        HSSFCell cell39 = row.createCell(39);
        cell39.setCellValue("集成读卡设备");
        //读卡属性和事项拥有属性赋值关系
        HSSFCell cell40 = row.createCell(40);
        cell40.setCellValue("读卡属性和事项拥有属性赋值关系");
        //是否加密
        HSSFCell cell41 = row.createCell(41);
        cell41.setCellValue("是否加密");
        //是否加签
        HSSFCell cell42 = row.createCell(42);
        cell42.setCellValue("是否加签");
        //是否加密展示
        HSSFCell cell43 = row.createCell(43);
        cell43.setCellValue("是否加密展示");
        //办理规则
        HSSFCell cell44 = row.createCell(44);
        cell44.setCellValue("办理规则");
    }
    private  static  void adjustmentCell(HSSFSheet sheet, Workbook workbook){
        // 遍历所有列，调整列宽
        for (int i = 0; i < sheet.getRow(0).getLastCellNum(); i++) {
            sheet.autoSizeColumn(i);
        }
    }

    /**
     * 算法填充
     * @param cell
     * @param bj
     */
    public static String fillAlgorith(int cell,JSONObject bj,JSONArray array,Integer flag){
        if (cell ==10){
            if (flag == null) {
                return ConstantUtils.SfBT0;
            }
            if (flag == 0) {
                return ConstantUtils.SfBT0;
            }
            StringBuilder sb = new StringBuilder();
            String attributes = bj.getString(ConstantUtils.AlgorithmAttributeSource);
            sb.append(ConstantUtils.SfBT1);
            sb.append("，算法触发属性：");
            sb.append(setAttribute(attributes, array));
            sb.append(";");
            return sb.toString();
        }else {
            String name = bj.getString(ConstantUtils.AlgorithmName);
            if(StringUtils.isBlank(name)){
                return ConstantUtils.DoubleLine;
            }
            if(name == null || "".equals(name) || name.length()<1){
                return ConstantUtils.DoubleLine;
            }
            StringBuilder sb = new StringBuilder();
            Integer backExecute = bj.getInteger(ConstantUtils.IsAlgorithmBackgroundExecution);
            sb.append(name);
            sb.append(";");
            sb.append("是否后台执行：");
            sb.append(assertISMustWriter(backExecute));
            return sb.toString();
        }

    }

    public static String setAttribute(String str,JSONArray array){
        String[] split = str.split(",");
        StringBuilder sb = new StringBuilder();
        HashMap<String, String> hmp = new HashMap<>(64);
        for (int j = 0; j < array.size() ; j++) {
            JSONObject jsonObject = array.getJSONObject(j);
            String fdf = jsonObject.getString(ConstantUtils.FieldIdentification);
            String fn = jsonObject.getString(ConstantUtils.FieldName);
            if(fdf != null){
                hmp.put(fdf,fn);
            }
        }
        for (int i = 0; i <split.length ; i++) {
            if(hmp.containsKey(split[i])){
                if(i==split.length-1){
                sb.append(hmp.get(split[i]));
                }else{
                    sb.append(hmp.get(split[i]));
                    sb.append("，");
                }

            }
        }
        return sb.toString();
    }

    /**
     * 获取登录信息数组
     * @return
     */
    private static HashMap searchLoginMessage(HashMap map) throws IOException {

        String url = "https://appcs.jbysoft.com/V2/GLDX/business/common/platformconfiguration$m=query.service";
        String body = "{\"type\":\"sxdy_dlxx\"}";
        String s = HttpUtils.doPost(url, map, body);
        System.out.println(s);
        HashMap hashMap = new HashMap(16);
        JSONObject responseObject = JSONObject.parseObject(s);
        if(responseObject.getBoolean("success")) {
            JSONArray outArray = responseObject.getJSONArray("results");
            for (int i = 0; i <outArray.size() ; i++) {
                JSONObject jsonObject = outArray.getJSONObject(i);
                String num = jsonObject.getString("num");
                String name = jsonObject.getString("name");
                if(num !=null){
                    hashMap.put(num,name);
                }
            }
            }
        return hashMap;
    }



    /**
     * 判断是否需要插入--
     * @param str
     * @return
     */
    private static String Assert__(String str){
        if(str ==null){
            return ConstantUtils.DoubleLine;
        }else {
            return str;
        }
    }
    private static String Assert__(Integer integer,HashMap map) throws IOException {

        if (integer == null) {
            return ConstantUtils.DoubleLine;
        } else {
            if(hashMap ==null) {
                hashMap = searchLoginMessage(map);
            }
            return hashMap.get(String.valueOf(integer)).toString();
        }
    }

    /**
     * 判断是否需要插入--
     * @param str
     * @return
     */
    private static String AssertXLKZSFS__(Integer str){
        if(str == null || "".equals(str)){
            return ConstantUtils.DoubleLine;
        }else if (str==1){
            return "树状";
        }else {
            return   "非树状";
        }
    }

    /**
     * 判断是否需要插入--
     * @param str
     * @return
     */
    private static String Assert__(Integer str){
        if(str == null || "".equals(str)){
            return ConstantUtils.DoubleLine;
        }else if (str==1){
            return "是";
        }else {
            return   "否";
        }
    }

    /**
     * 模糊搜索
     * @param integer
     * @return
     */
    private static String isSupportFuzzySearch( Integer isFuzzy , Integer integer) {

        if (isFuzzy == 1){
            if (integer ==1){
                return  "是；是否区分大小写搜索：是";
            }else {
                return  "是；是否区分大小写搜索：否";
            }
        }else{
            return ConstantUtils.SfBT0;
        }
    }

    private static String  setNodeMessage(Integer sfxzlcjd,Integer sfzyfymxs ,JSONArray jsonArray) {
        if (sfxzlcjd == null || "".equals(sfxzlcjd)) {
            return ConstantUtils.DoubleLine;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("是；");
        if ( sfzyfymxs != null &&  sfzyfymxs == 1){
            sb.append("是；");
        }else {
            sb.append("否；");
        }
        for (int i = 0; i < jsonArray.size() ; i++) {
            JSONObject object = jsonArray.getJSONObject(i);
            String lcjdmc = object.getString("lcjdmc");
            sb.append(lcjdmc);
            sb.append("；");
            Integer ishow = object.getInteger("sfxs");
            Integer sfbj = object.getInteger("sfbj");
            if (ishow != null &&  ishow == 1){
                sb.append("是；");
            }else {
                sb.append("否；");
            }
            if ( sfbj != null && sfbj == 1){
                sb.append("是；");
            }else {
                sb.append("否；");
            }
        }
    return sb.toString();
    }

}
